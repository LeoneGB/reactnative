/**
 * Codia React Native App
 * https://codia.ai
 * https://github.com/facebook/react-native
 *
 * @format
 */
import React from 'react';
import {
  View,
  Text,
  ImageBackground,
  SafeAreaView,
  ScrollView,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';

export default function App(): React.JSX.Element {
  return (
    <SafeAreaView>
      <ScrollView
        scrollEnabled={true}
        contentInsetAdjustmentBehavior='automatic'
      >
        <View
          style={{
            width: 430,
            height: 932,
            borderTopLeftRadius: 20,
            borderTopRightRadius: 20,
            borderBottomRightRadius: 20,
            borderBottomLeftRadius: 20,
            position: 'relative',
            overflow: 'hidden',
            marginTop: 0,
            marginRight: 'auto',
            marginBottom: 0,
            marginLeft: 'auto',
          }}
        >
          <View
            style={{
              width: 460,
              height: 380,
              position: 'relative',
              marginTop: -60,
              marginRight: 0,
              marginBottom: 0,
              marginLeft: 0,
            }}
          >
            <ImageBackground
              style={{
                width: 236,
                height: 304,
                position: 'relative',
                zIndex: 12,
                marginTop: 60,
                marginRight: 0,
                marginBottom: 0,
                marginLeft: 97,
              }}
              source={require('./assets/images/8eec2e43cce4a0226fce430ba901b8515cb28c9b.png')}
              resizeMode='cover'
            >
              <ImageBackground
                style={{
                  width: 1,
                  height: 1,
                  position: 'relative',
                  zIndex: 11,
                  marginTop: 147,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 162,
                }}
                source={require('./assets/images/8eec2e43cce4a0226fce430ba901b8515cb28c9b.png')}
                resizeMode='cover'
              />
            </ImageBackground>
          </View>
          <Text
            style={{
              height: 20,
              fontFamily: 'Inter',
              fontSize: 14,
              fontWeight: '400',
              lineHeight: 19.6,
              color: '#ffffff',
              position: 'relative',
              textAlign: 'left',
              zIndex: 7,
              marginTop: 19,
              marginRight: 0,
              marginBottom: 0,
              marginLeft: 86,
            }}
            numberOfLines={1}
          >
            EMAIL:
          </Text>
          <View
            style={{
              width: 270,
              height: 46,
              backgroundColor: '#ffffff',
              borderTopLeftRadius: 15,
              borderTopRightRadius: 15,
              borderBottomRightRadius: 15,
              borderBottomLeftRadius: 15,
              position: 'relative',
              zIndex: 2,
              marginTop: -1,
              marginRight: 0,
              marginBottom: 0,
              marginLeft: 80,
            }}
          />
          <Text
            style={{
              width: 56,
              height: 20,
              fontFamily: 'Inter',
              fontSize: 14,
              fontWeight: '400',
              lineHeight: 19.6,
              position: 'relative',
              textAlign: 'left',
              zIndex: 8,
              marginTop: 18,
              marginRight: 0,
              marginBottom: 0,
              marginLeft: 86,
            }}
          >
            <Text
              style={{
                fontFamily: 'Inter',
                fontSize: 14,
                fontWeight: '400',
                lineHeight: 19.6,
                color: '#ffffff',
                position: 'relative',
                textAlign: 'left',
              }}
            >
              SENHA:
            </Text>
            <Text
              style={{
                fontFamily: 'Inter',
                fontSize: 14,
                fontWeight: '400',
                lineHeight: 19.6,
                color: '#000000',
                position: 'relative',
                textAlign: 'left',
              }}
            >
              :
            </Text>
          </Text>
          <View
            style={{
              width: 270,
              height: 46,
              backgroundColor: '#ffffff',
              borderTopLeftRadius: 15,
              borderTopRightRadius: 15,
              borderBottomRightRadius: 15,
              borderBottomLeftRadius: 15,
              position: 'relative',
              zIndex: 3,
              marginTop: 1,
              marginRight: 0,
              marginBottom: 0,
              marginLeft: 80,
            }}
          />
          <Text
            style={{
              width: 128,
              height: 20,
              fontFamily: 'Inter',
              fontSize: 14,
              fontWeight: '400',
              lineHeight: 19.6,
              position: 'relative',
              textAlign: 'left',
              zIndex: 6,
              marginTop: 16,
              marginRight: 0,
              marginBottom: 0,
              marginLeft: 86,
            }}
          >
            <Text
              style={{
                fontFamily: 'Inter',
                fontSize: 14,
                fontWeight: '400',
                lineHeight: 19.6,
                color: '#c7c6c6',
                position: 'relative',
                textAlign: 'left',
                textDecorationLine: 'underline',
              }}
            >
              Esqueceu a senha?
            </Text>
          </Text>
          <View
            style={{
              width: 270,
              height: 46,
              backgroundColor: '#2c2c2c',
              borderTopLeftRadius: 12,
              borderTopRightRadius: 12,
              borderBottomRightRadius: 12,
              borderBottomLeftRadius: 12,
              position: 'relative',
              zIndex: 4,
              marginTop: 47,
              marginRight: 0,
              marginBottom: 0,
              marginLeft: 80,
            }}
          >
            <Text
              style={{
                display: 'flex',
                height: 16,
                justifyContent: 'flex-start',
                alignItems: 'flex-start',
                fontFamily: 'Inter',
                fontSize: 16,
                fontWeight: '400',
                lineHeight: 16,
                color: '#ffffff',
                position: 'absolute',
                top: 15,
                left: 103,
                textAlign: 'left',
                zIndex: 9,
              }}
              numberOfLines={1}
            >
              ENTRAR
            </Text>
          </View>
          <View
            style={{
              width: 270,
              height: 48,
              backgroundColor: '#2c2c2c',
              borderTopLeftRadius: 12,
              borderTopRightRadius: 12,
              borderBottomRightRadius: 12,
              borderBottomLeftRadius: 12,
              position: 'relative',
              zIndex: 5,
              marginTop: 38,
              marginRight: 0,
              marginBottom: 0,
              marginLeft: 79,
            }}
          >
            <Text
              style={{
                display: 'flex',
                height: 16,
                justifyContent: 'flex-start',
                alignItems: 'flex-start',
                fontFamily: 'Inter',
                fontSize: 16,
                fontWeight: '400',
                lineHeight: 16,
                color: '#ffffff',
                position: 'absolute',
                top: 16,
                left: 79,
                textAlign: 'left',
                zIndex: 10,
              }}
              numberOfLines={1}
            >
              CADASTRE-SE
            </Text>
          </View>
          <ImageBackground
            style={{
              width: 576,
              height: 1216,
              position: 'absolute',
              top: -179,
              left: -46,
              zIndex: 1,
            }}
            source={require('./assets/images/db839a50e9435a09b437478436e472fc211d9a50.png')}
            resizeMode='cover'
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
